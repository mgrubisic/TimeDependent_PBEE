#include <stdio.h>
#include "constraint.h"

void constraintPrint(Constraint *theConstraint){
  printf("Constraint : %d ", theConstraint->tag);
  printf("Constrained node: %d ", theConstraint->nodeTag);
  printf("Constraints in dx, dy, rz: %b %b %b \n", theConstraint->constrained[0], theConstraint->constrained[1], theConstraint->constrained[2]);
}

void constraintSetup(Constraint *theConstraint, int tag, bool c1, bool c2, bool c3) {
  theConstraint->tag = tag;
  theConstraint->constrainedNode = nodeTag;
  theConstraint->constrained[0] = c1;
  theConstraint->constrained[1] = c2;
  theConstraint->constrained[2] = c3;
  theConstraint->next = NULL;
}
