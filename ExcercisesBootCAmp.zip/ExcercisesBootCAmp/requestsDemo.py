import requests
import csv

#Let's request the tall buildings information
response_sfgov = requests.get("https://data.sfgov.org/resource/5kya-mfst.json")

#Let's check the response is OK (return code 200)
if(response_sfgov.status_code == 200):
    #We will convert the response to json 
    tallBuildings = response_sfgov.json()
    
    #Open CSV File
    with open('SF_TallBuildings.csv','w') as csvfile:
        fieldnames=['Building Name','Occupancy','Address','Structural System','Number of Stories','Area','Longitude','Latitude','PGA']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        #writer.writeheader()
        #we will read the first building in the response and print some information
        for building in tallBuildings:
            print("Building Name :", building["name"])
            name=building["name"]
            print("\tOccupancy: ", building["occupancy"])
            occ=building["occupancy"]
            print("\tAddress: ", building["address"])
            addr=building["address"]
            print("\tStructure Type: ", building["structural_types"])
            stype=building["structural_types"]
            if "stories_above_grade" in building:
                print("\tNumber of Stories: ", building["stories_above_grade"])
                stories=building["stories_above_grade"]
            else: 
                print("\tNumber of Stories: Unknown")
                stories="Unknown"
            print("\tTotal Area: ", building["shape_area"])
            area=building["shape_area"]
            coord=building["polygon"]["coordinates"][0][0]
            long=coord[0]
            lat=coord[1]
            print("\tLongitude: ",long)
            print("\tLatitude: ",lat)

            #Obtaining PGA Data from USGS website
            query="https://earthquake.usgs.gov/ws/designmaps/asce7-16.json?"+"latitude="+str(lat)+"&longitude="+str(long)+"&riskCategory=III&siteClass=C&title="+building["name"]
            response_usgs = requests.get(query)
            usgs_design=response_usgs.json()
            pga=usgs_design["response"]["data"]["pga"]
            print("\tPGA: ",pga)
        
        
            #Write parameters to csv file
            #writer.writerow({'Building Name': "hola"})
            writer.writerow([name,occ,addr,stype,stories,area,long,lat,pga])


#Excercise 1: Print to the screen the list of buildings 
#including relevant information about the building like structure type
#occupancy, number of stories, , total area.


#Excercise 2: Write the data from excercise 1 into a csv text file including latitude and longitude


#Exercise 3: Can we get PGA from USGS API for each building and include it in the output file