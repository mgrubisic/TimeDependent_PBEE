#include <stdio.h>
#include <stdlib.h>

int factorial(int n);


// recursive function sum of arguments, i.e. it calls itself
int sumIntArr(int n) {
  if (n == 1) 
    return 1;
  else 
    return n*factorial(n-1);
}
	      
