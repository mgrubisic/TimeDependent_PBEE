import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(-np.pi,np.pi, 100)
y1=np.sin(x)
y2=np.cos(x)
y3=np.tan(x)
plt.ylim(-1.5,1.5)
plt.grid

plt.plot(x, y1, label='sin(x)')
plt.plot(x, y2, label='cos(x)')
plt.plot(x, y3, label='tan(x)')

plt.xlabel('Angle')
plt.ylabel('y')

plt.title("Trigonometric Plots")
plt.grid()
plt.legend()

#plt.show()

plt.savefig('Trig2.pdf')
plt.savefig('Trig2.png', dpi=300)
