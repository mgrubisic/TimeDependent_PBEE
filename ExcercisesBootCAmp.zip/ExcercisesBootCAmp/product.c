#include <stdio.h>

float prodFloat(float a,float b);
float main() {
	float float1, float2, prod;
	printf("Enter first float: ");
	scanf("%f", &float1); // read input to float 1
	printf("Enter second float: ");
	scanf("%f", &float2); // read input to float 2
	prod = prodFloat(float1, float2);
	printf("product %f + %f = %f\n", float1, float2, prod);
	return(0);
	}

// your code here
float prodFloat(float a, float b) {
	return(a*b); //product of both floats
}

